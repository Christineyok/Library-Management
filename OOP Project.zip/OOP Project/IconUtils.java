import javax.swing.ImageIcon;
import java.awt.Image;

public class IconUtils {

    public static ImageIcon resizeIcon(String iconPath, int newWidth, int newHeight) {
        ImageIcon originalIcon = new ImageIcon(iconPath);
        Image resizedImage = originalIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImage);
    }
}
